// sellections
const searInput = document.querySelector(".search-input");
const searbtn = document.querySelector(".search-btn");
const flags = document.querySelector(".flags");
const country_info = document.querySelector(".country-info");
const background_img = document.querySelector(".background-img");
const weather_container = document.querySelector(".weather-container");


// search Event
searbtn.addEventListener("click", (e) =>{
    // APi URL
    const apiURL = `https://restcountries.com/v3.1/name/${searInput.value}?fullText=true`;

    // fetching api
    fetch(apiURL)
    .then((response) =>{
        return response.json();
    })
    .then((data) =>{
        console.log("============== Country Api =============");
        console.log(data[0]);
        const Conuntryflag = data[0].flags.svg;
        const Arms = data[0].coatOfArms.svg;
        const name = data[0].name.common;
        country_info.style.display = "block";
            flags.innerHTML = `
            <div class="flag-img" >
            <img src=${Conuntryflag}  alt="" class='country_name'>
            <p id="countr-Nam">${data[0].name.common}</p>
            </div>
            <div class='coat'>
            <img src=${Arms}  alt="">
            <p class="countr-Nam">Coat of Arms</p>
            </div>
            `
            country_info.innerHTML = `
                <p> Name:<span class="name">${data[0].name.common}</span></p> 
                <p> Continents:<span class="name">${data[0].continents}</span></p> 
                <p> Languages:<span class="name">${Object.values(data[0].languages).toString().split(",").join(",")}</span></p> 
                <p> Population:<span class="name">${data[0].population.toLocaleString()}</span></p> 
                <p> Borders:<span class="name">${data[0].borders}</span></p> 
                <p> Capital:<span class="name">${data[0].capital}</span></p> 
                <p> Currencies:<span class="name">${data[0].currencies[Object.keys(data[0].currencies)].name}  (${data[0].currencies[Object.keys(data[0].currencies)].symbol})</span></p> 
            `

        
    }).catch(() => {
        if(searInput.value.length == 0) {
            flags.innerHTML = `
                <h3>The input field can not be empty!</h3>
            `
            country_info.style.display = "none";
        }
        else{
            flags.innerHTML = `
                <h3>Please Enter a valid country name!</h3>
            `
            country_info.style.display = "none";
        }
    });




    // Picture Generator api
    
    const img_api_KEY = `26736331-e601f34b0ba29debfaa8724e4`;
    const img_apiURL = `https://pixabay.com/api/?key=${img_api_KEY}&q=${searInput.value
    }&image_type=photo
    `;
    const video_apiURL = `https://pixabay.com/api/videos/?key=26736331-e601f34b0ba29debfaa8724e4&q=japan
    `;
    fetch(img_apiURL)
    .then((response) =>{
        return response.json();
    })
    .then((data) =>{
        const hits = data.hits[2].largeImageURL
        // console.log(hits)
        background_img.innerHTML = `
        <img src=${hits} class="bg-img">
        `;
    })

    
    
    
    // weather api function
    function weather(){
    
        // weather api
        const weatherApi_KEY = `https://api.openweathermap.org/data/2.5/weather?q=${searInput.value}&appid=cc5179e599f3041b343edabc09673ae4&units=metric`;
    
        fetch(weatherApi_KEY)
        .then((response) =>{
            console.log("=============== Weather Api ================")
            // console.log(response.json());
            return response.json();
        })
        .then((data) =>{
            console.log(data)
            const temp = data.main.temp;
            weather_container.innerHTML = `
            <div class="weather-icon">
            <ion-icon name="partly-sunny-outline" class='w-icon'></ion-icon><p class='wearther-title'>${temp}</p>
            <ion-icon name="radio-button-off-outline" class="degree-symbol"></ion-icon>
        </div>
            `
        })
    }
    
    weather();

})

